

/home/ocardona/Windows/src/SD/_ndkci/
>> find . -type d | egrep -i ndk
./net/test/transports/RDMA/bvt/tests/Logo/Ndkpi
./net/test/transports/RDMA/bvt/umndkpilib
./net/test/transports/RDMA/bvt/umndkpilib/inc
./vm/test/tools/vm/SendKey

ocardona@ocardona-x:
/home/ocardona/Windows/src/SD/_ndkci/
>> find . -type d | egrep -i rdma
./minio/netio/framing/rdma
./minio/netio/framing/rdma/nt
./minio/netio/framing/rdma/usersim
./net/test/transports/RDMA
./net/test/transports/RDMA/bvt
./net/test/transports/RDMA/bvt/client
./net/test/transports/RDMA/bvt/inc
./net/test/transports/RDMA/bvt/sys
./net/test/transports/RDMA/bvt/sys/inf
./net/test/transports/RDMA/bvt/sys/ndis64
./net/test/transports/RDMA/bvt/sys/ndis65
./net/test/transports/RDMA/bvt/sys/ndis660
./net/test/transports/RDMA/bvt/tests
./net/test/transports/RDMA/bvt/tests/api
./net/test/transports/RDMA/bvt/tests/CommonHelper
./net/test/transports/RDMA/bvt/tests/Diagnostics
./net/test/transports/RDMA/bvt/tests/Logo
./net/test/transports/RDMA/bvt/tests/Logo/Common
./net/test/transports/RDMA/bvt/tests/Logo/controller
./net/test/transports/RDMA/bvt/tests/Logo/Diagnostics
./net/test/transports/RDMA/bvt/tests/Logo/inc
./net/test/transports/RDMA/bvt/tests/Logo/Main
./net/test/transports/RDMA/bvt/tests/Logo/Manageability
./net/test/transports/RDMA/bvt/tests/Logo/Ndkpi
./net/test/transports/RDMA/bvt/tests/Logo/Server
./net/test/transports/RDMA/bvt/tests/main
./net/test/transports/RDMA/bvt/tests/Manageability
./net/test/transports/RDMA/bvt/tests/PnP
./net/test/transports/RDMA/bvt/tests/wsk
./net/test/transports/RDMA/bvt/umndkpilib
./net/test/transports/RDMA/bvt/umndkpilib/inc
./net/test/transports/RDMA/bvt/wlk
./net/test/transports/RDMA/bvt/wlk/Content
./net/test/transports/RDMA/client
./net/test/transports/RDMA/client/inc
./net/test/transports/RDMA/client/lib
./net/test/transports/RDMA/client/sys
./net/test/transports/RDMA/hw
./net/test/transports/RDMA/miniport
./net/test/transports/RDMA/miniport/sys
./net/test/transports/RDMA/miniport/sys/inf
./net/test/transports/RDMA/miniport/sys/ndis630
./net/test/transports/WMI/utils/Extensions/NetAdapterRdmaExtension
./vm/dv/net/nvsp/tests/rdma
./vm/dv/net/nvsp/tests/rdma/Test Scripts


